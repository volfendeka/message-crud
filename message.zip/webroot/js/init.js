(function () {
    eventHandler.init();
})();
