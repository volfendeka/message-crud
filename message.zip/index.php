<?php

namespace app\core;

require_once("app/core/Config.php");

new Config();
new Router();


?>




