<?php
echo 'index from user controller <br>';